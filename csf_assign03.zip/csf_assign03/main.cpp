#include <iostream>

int main( int argc, char **argv ) {
  // TODO: implement

  return 0;
}
